const express = require('express')
const mongoose = require('mongoose')
const url = 'mongodb://localhost/AlienDBex'

const app = express()


// use checking connection for mongose connection
mongoose.connect(url, {useNewUrlParser:true})
const con = mongoose.connection

con.on('open', () => {
    console.log('connected...')
})

// use middlware for store json data and use it 
app.use(express.json())


// import router path 
const umpRouter = require('./routes/route')

// new page url 
app.use('/new',umpRouter)



// genrate port number
app.listen(9000, () => {
    console.log('Server started')
})